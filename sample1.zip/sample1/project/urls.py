from django.contrib import admin
from django.urls import path,include
from . import views
urlpatterns = [
    path('',views.index,name="index"),
    path('certificate',views.download_certificate,name="certificate"),
    path('campus',views.our_campus,name="campus"),
    path('knowledge',views.knowledge_skill,name="campus"),
    path('cyber',views.cyber_security,name="cyber"),
    path('operations',views.security_operations,name="operations"),
    path('conference',views.conference,name="conference"),
    path('course1',views.course1,name="course1"),
    path('course2',views.course2,name="course2"),
    path('course3',views.course3,name="course3"),
    path('course4',views.course4,name="course4"),
    path('course5',views.course5,name="course5"),
    path('course6',views.course6,name="course6"),
    path('course7',views.course7,name="course7"),
    path('course8',views.course8,name="course8"),
]