from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'index.html')
def download_certificate(request):
    return render(request,'download.html')
def our_campus(request):
    return render(request,'our_campus.html')
def knowledge_skill(request):
    return render(request,'knowledge.html')
def cyber_security(request):
    return render(request,'cyber_security.html')
def security_operations(request):
    return render(request,'security_operations.html')
def conference(request):
    return render(request,'conference.html')
def course1(request):
    return render(request,'course1.html')
def course2(request):
    return render(request,'course2.html')
def course3(request):
    return render(request,'course3.html')
def course4(request):
    return render(request,'course4.html')
def course5(request):
    return render(request,'course5.html')
def course6(request):
    return render(request,'course6.html')
def course7(request):
    return render(request,'course7.html')
def course8(request):
    return render(request,'course8.html')
