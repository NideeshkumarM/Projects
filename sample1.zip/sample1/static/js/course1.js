document.addEventListener('DOMContentLoaded', () => {
    const enrollButton = document.querySelector('.enroll-button');

    enrollButton.addEventListener('click', () => {
        enrollButton.textContent = 'Enrolled!';
        enrollButton.style.backgroundColor = '#28a745';
    });
});
